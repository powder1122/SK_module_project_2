# pages/Quiz_Game.py
import streamlit as st
import random
import os
from core.db_manager import DBManager
import time # 타이머 기능을 위해 추가

# --- DB 연결 및 문제 가져오기 ---
if 'db' not in st.session_state:
    # 프로젝트 최상위 폴더를 기준으로 절대 경로를 생성해주는 코드
    DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'quiz_questions.db')
    st.session_state.db = DBManager(DB_PATH)
    st.session_state.questions = st.session_state.db.get_all_questions()
    random.shuffle(st.session_state.questions)

# --- 게임 상태 변수 초기화 ---
if 'game_started' not in st.session_state:
    st.session_state.game_started = False
if 'current_question_index' not in st.session_state:
    st.session_state.current_question_index = 0
if 'score' not in st.session_state:
    st.session_state.score = 0
if 'game_finished' not in st.session_state:
    st.session_state.game_finished = False
if 'user_answers' not in st.session_state:
    st.session_state.user_answers = []

# --- 게임 시작 버튼 ---
if not st.session_state.game_started:
    st.title("피싱 제로 🎮")
    st.write("아래 버튼을 눌러 게임을 시작하세요! 총 10문제를 풀어야 합니다.")
    if st.button("게임 시작"):
        st.session_state.game_started = True
        st.session_state.current_question_index = 0
        st.session_state.score = 0
        st.session_state.game_finished = False
        st.session_state.user_answers = []
        st.rerun()

# --- 게임 화면 구성 ---
if st.session_state.game_started and not st.session_state.game_finished:
    # 현재 문제 정보 가져오기
    if st.session_state.questions:
        current_question = st.session_state.questions[st.session_state.current_question_index]
    
        st.title(f"문제 {st.session_state.current_question_index + 1} / {len(st.session_state.questions)}")
        st.write(f"현재 점수: {st.session_state.score}점")

        st.subheader("이메일 텍스트를 분석해보세요!")
        # DB 스키마에 맞게 'subject'와 'body'를 함께 표시
        st.info(f"**제목:** {current_question['subject']}")
        st.text_area("이메일 내용", current_question['body'], height=200, disabled=True)
        
        # 사용자가 아직 답변을 제출하지 않았을 때
        if 'submitted' not in st.session_state or st.session_state.submitted is False:
            user_choice = st.radio(
                "이 이메일은 피싱일까요?",
                ('피싱', '정상'),
                index=None,
                key=f"question_{st.session_state.current_question_index}"
            )
            
            if st.button("답변 제출"):
                if user_choice is None:
                    st.warning("정답을 선택해주세요!")
                else:
                    # [수정됨] 'label' 컬럼을 기준으로 정답 확인 (1: 피싱, 0: 정상)
                    correct_answer = '피싱' if current_question['label'] == 1 else '정상'
                    is_correct = (user_choice == correct_answer)
                    
                    st.session_state.user_answers.append({
                        'question_data': current_question,
                        'user_choice': user_choice,
                        'is_correct': is_correct
                    })
                    
                    # 정답 여부에 따른 메시지 출력
                    if is_correct:
                        st.session_state.score += 10
                        st.success("🎉 정답입니다!")
                    else:
                        st.error("😭 아쉽지만 오답입니다.")
                    
                    st.session_state.submitted = True
                    st.rerun()
                    
        # 사용자가 답변을 제출한 후 '다음 문제' 버튼 표시
        elif st.session_state.submitted is True:
            is_correct = st.session_state.user_answers[-1]['is_correct']
            
            if is_correct:
                st.success("🎉 정답입니다!")
            else:
                st.error("😭 아쉽지만 오답입니다.")
                
            if st.button("다음 문제"):
                st.session_state.current_question_index += 1
                if st.session_state.current_question_index >= len(st.session_state.questions):
                    st.session_state.game_finished = True
                
                st.session_state.submitted = False # 제출 상태 초기화
                st.rerun()
                
    else:
        st.error("퀴즈 문제가 준비되지 않았습니다. 데이터베이스를 확인해주세요.")

# --- 게임 종료 화면 ---
if st.session_state.game_finished:
    st.title("게임 종료! 🥳")
    st.write(f"최종 점수는 **{st.session_state.score}점**입니다!")
    st.success("이제 모든 문제에 대한 Gemini의 해설을 보러 갈까요?")
    
    st.page_link("pages/2_📈_Result.py", label="결과 보기", icon="📈")