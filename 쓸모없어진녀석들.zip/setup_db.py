# setup_db.py
import sqlite3
import os
from quiz_data import quiz_data

def setup_database():
    """데이터베이스를 생성하고 초기 퀴즈 데이터를 삽입하는 함수"""
    db_path = os.path.join("data", "quiz_questions.db")
    
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # 테이블 스키마는 그대로 유지
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS quiz_questions (
            id INTEGER PRIMARY KEY,
            subject TEXT,
            body TEXT NOT NULL,
            label INTEGER NOT NULL
        )
    ''')
    
    cursor.execute("DELETE FROM quiz_questions")
    
    # 4개의 컬럼(id, subject, body, label)에 데이터를 삽입하도록 수정
    cursor.executemany(
        "INSERT INTO quiz_questions (id, subject, body, label) VALUES (?, ?, ?, ?)", 
        quiz_data
    )
    
    conn.commit()
    conn.close()
    
    print(f"데이터베이스에 {len(quiz_data)}개의 퀴즈 문제가 성공적으로 저장되었습니다.")

if __name__ == "__main__":
    setup_database()