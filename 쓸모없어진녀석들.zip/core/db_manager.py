# core/db_manager.py
# 데이터베이스 관리 모듈
import sqlite3
import pandas as pd

class DBManager:
    """
    SQLite 데이터베이스를 관리하는 클래스입니다.
    퀴즈 문제 데이터를 불러오고 관리하는 기능을 제공합니다.
    """
    def __init__(self, db_path):
        """데이터베이스 경로를 인자로 받아 연결을 설정합니다."""
        self.conn = sqlite3.connect(db_path)
        self.cursor = self.conn.cursor()
        self.create_table() # 테이블이 없으면 생성

    def create_table(self):
        """퀴즈 문제 데이터를 저장할 테이블을 생성합니다."""
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS quiz_questions (
                id INTEGER PRIMARY KEY,
                subject TEXT,
                body TEXT NOT NULL,
                label INTEGER NOT NULL
            )
        ''')
        self.conn.commit()

    def get_all_questions(self):
        """데이터베이스에 있는 모든 퀴즈 문제를 불러옵니다."""
        self.cursor.execute("SELECT subject, body, label FROM quiz_questions")
        questions = self.cursor.fetchall()
        
        # 불러온 데이터를 딕셔너리 리스트로 변환하여 반환
        return [
            {'subject': q[0], 'body': q[1], 'label': bool(q[2])} for q in questions]

    def close(self):
        """데이터베이스 연결을 닫습니다."""
        self.conn.close()